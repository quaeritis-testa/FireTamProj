package com.sredstva.firetam;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;


import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Picture;
import android.os.Build;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.os.CountDownTimer;

public class MainActivity extends AppCompatActivity {
    public int saturation;
    public int happiness;
    public int money = 50;

    public int vichitatelSat = 1;
    public int vichitatelHap = 1;
    public int incomeMoney = 1;

    final String SAVED_SATUR = "saved_satur";
    final String SAVED_HAP = "saved_hap";
    final String SAVED_MONEY = "saved_money";
    SharedPreferences sPref;

    public int[] ItemOpts; // 0 цена, 1 насыщаемость, 2 нарадоваемость
    int[][] shopItemList = {{10, 15, 5}, {5, 10, 5}, {5, 5, 10}, {10, 10, 10}, {15, 1, 15}};
    String[] shopList = { "Уголь 10Р", "Палка 5Р", "Бумага 5Р", "Бревно 10Р", "Фотография 15Р"};

    public  CountDownTimer countDownTimer;

    private long timeLeftMilliSec = 1000;

    int incomeTime = 5;
    int nowIncomeTime;

    Button feedButton;
    ImageView ogonok;

    ProgressBar satProgBar;
    ProgressBar hapProgBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Game();
        loadSmth();
        if(saturation == 0) {
            saturation = 100;
            happiness = 100;
            money = 50;
        }
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel("My Notif", "My Notif", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }
    public void Game(){
        setContentView(R.layout.activity_main);
        final TextView monText = findViewById(R.id.monText);
        //ogonok = findViewById(R.id.ogonokpict);
        feedButton  = findViewById(R.id.feed_button);
        satProgBar = (ProgressBar) findViewById(R.id.saturation_progress_bar);
        hapProgBar = (ProgressBar) findViewById(R.id.happiness_progress_bar);
        final Spinner spinner = findViewById(R.id.shop_spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, shopList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        countDownTimer = new CountDownTimer(timeLeftMilliSec, 1000) {
            @Override
            public void onTick(long l) {
                ItemOpts = shopItemList[spinner.getSelectedItemPosition()];
                if(money>999){
                    monText.setText("    "+money);
                }
                if(money>99){
                    monText.setText("     "+money);
                }
                if(money<=99){
                    monText.setText("      "+money);
                }
                if(money<10){
                    monText.setText("        "+money);
                }

                Update();
                //PictureChanger();
                Limits();
                Notifs();
                SaveSmth();

                //spinner.getSelectedItemPosition()
            }
            @Override
            public void onFinish() {
                countDownTimer.start();
            }
        }.start();

        feedButton.setOnClickListener(v -> Feeding());

    }
    public void Feeding(){
        if(money>=ItemOpts[0]){
            money -= ItemOpts[0];
            saturation += ItemOpts[1];
            happiness += ItemOpts[2];
        }
    }
    public void Update(){
        nowIncomeTime++;
        satProgBar.setProgress(saturation);
        hapProgBar.setProgress(happiness);

        saturation -= vichitatelSat;
        happiness -= vichitatelHap;

        if(saturation < 50){
            vichitatelHap = 2;
        }else{
            vichitatelHap = 1;
        }
        if(happiness < 50){
            vichitatelSat = 2;
            incomeMoney = 3;
        }else{
            vichitatelSat = 1;
            incomeMoney = 5;
        }

        if(nowIncomeTime == incomeTime){
            money += incomeMoney;
            nowIncomeTime = 0;
        }
    }
    public void Death(){

    }
    public void Limits(){
        if(saturation>=100){
            saturation = 100;
        }else if(saturation <= 0){
            saturation = 0;
            nowIncomeTime = 0;
        }
        if(happiness>=100){
            happiness = 100;
        }else if(happiness <= 0){
            happiness = 0;
            nowIncomeTime = 0;
        }
    }
    public void Notifs(){
        Intent resultIntent = new Intent(this, MainActivity.class);

        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        stackBuilder.addParentStack(MainActivity.class);
        stackBuilder.addNextIntent(resultIntent);

        /*PendingIntent resultPendingIntent =
                stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);*/
        if(saturation == 60){
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 1, intent, PendingIntent.FLAG_ONE_SHOT);

            NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, "My Notif");
            builder.setContentTitle("Пора кормить огонька");
            builder.setContentText("Огонёк нуждается в еде!");
            builder.setSmallIcon(R.drawable.fire_icon);
            builder.setAutoCancel(true);
            builder.setContentIntent(pendingIntent);

            NotificationManagerCompat managerCompat = NotificationManagerCompat.from(MainActivity.this);
            managerCompat.notify(1, builder.build());
        }
        if(saturation == 1){
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 1, intent, PendingIntent.FLAG_ONE_SHOT);

            NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, "My Notif");
            builder.setContentTitle("Огонёк погас");
            builder.setContentText("Нажмите для новой игры");
            builder.setSmallIcon(R.drawable.fire_icon);
            builder.setAutoCancel(true);
            builder.setContentIntent(pendingIntent);

            NotificationManagerCompat managerCompat = NotificationManagerCompat.from(MainActivity.this);
            managerCompat.notify(1, builder.build());
        }
    }
    /*public void PictureChanger(){
        if(saturation>50){
            ogonok.setImageResource(R.drawable.ogonok);
        }
        if(saturation<= 50 && saturation>25){
            ogonok.setImageResource(R.drawable.ogonok1);
        }
        if(saturation <=25){
            ogonok.setImageResource(R.drawable.ogonok2);
        }
    }*/
    public void SaveSmth(){
        sPref = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor ed = sPref.edit();
        ed.clear();
        ed.putString(SAVED_SATUR, String.valueOf(saturation));
        ed.putString(SAVED_HAP, String.valueOf(happiness));
        ed.putString(SAVED_MONEY, String.valueOf(money));
        ed.apply();
    }
    void loadSmth() {
        sPref = getPreferences(MODE_PRIVATE);
        String savedSatur = sPref.getString(SAVED_SATUR, "0");
        String savedHap = sPref.getString(SAVED_HAP, "0");
        String savedMoney = sPref.getString(SAVED_MONEY, "0");
        saturation = Integer.parseInt(savedSatur);
        happiness = Integer.parseInt(savedHap);
        money = Integer.parseInt(savedMoney);
    }
}