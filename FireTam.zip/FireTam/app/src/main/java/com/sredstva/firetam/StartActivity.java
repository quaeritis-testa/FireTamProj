package com.sredstva.firetam;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.motion.widget.Debug;
import androidx.fragment.app.Fragment;

public class StartActivity extends AppCompatActivity{
    Button playGame;
    Button aboutBtn;
    TextView finalText;
    public boolean a = false;
    //LinearLayout fragLayout = this.findViewById(R.id.fragm_about_layout);
    final String SAVED_MONEY = "saved_money";
    SharedPreferences sPref;

    public int money;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .add(R.id.fragment_container_view_about, FragmentAbout.class, null)
                    .commit();
        }
        setContentView(R.layout.start_activity);

        playGame = findViewById(R.id.startButton);
        aboutBtn = findViewById(R.id.aboutButton);
        loadSmth();
        playGame.setOnClickListener(v -> startActivity(new Intent(StartActivity.this, GameActivity.class)));
        aboutBtn.setOnClickListener(v -> showFragment());
        //fragLayout.setOnClickListener(v -> hideFragment());
    }
     void loadSmth() {
        sPref = getSharedPreferences("myPref",MODE_PRIVATE);
        String savedMoney = sPref.getString(SAVED_MONEY, "0");
        money = Integer.parseInt(savedMoney);
    }
    public void hideFragment(){
        LinearLayout fragLayout = this.findViewById(R.id.fragm_about_layout);
        fragLayout.setVisibility(LinearLayout.GONE);
    }
    public void showFragment(){
        LinearLayout fragLayout = this.findViewById(R.id.fragm_about_layout);
        if(a == false){
            fragLayout.setVisibility(LinearLayout.VISIBLE);
            a=true;
        }else {
            fragLayout.setVisibility(LinearLayout.GONE);
            a=false;
        }
    }

}
